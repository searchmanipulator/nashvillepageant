<div id="dm_albums_album_detail_manager_container" style="position:absolute; width: 670px; height: 95%; top: 20px; left: 100px; background: #FFFFFF; border: 1px solid #464646; visibility: hidden; z-index: 1000000;"><div id="dm_albums_detail_manager_titlebar"><div id="dm_albums_detail_manager_titlebar_title">DM Albums Album Detail Manager</div><div id="dm_albums_detail_manager_titlebar_close"><a href="javascript:dm_HideDetailManager();" title="Close"><img src="../wp-includes/js/thickbox/tb-close.png"></a></div></div>

<div id="dm_albums_album_detail_manager"></div>

</div>